<?php

/**
 * BackendPicturesAjaxSequence
 *
 * @author Sam Tubbax <sam@sumocoders.be>
 */
class BackendPicturesAjaxSequence extends BackendBaseAJAXAction
{

}